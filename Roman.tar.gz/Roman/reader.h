
int minimo(int *numbers[], int length);
int maximo(int *numbers[], int length);
int sumatorio(int *numbers[], int length);
void printStack(struct my_stack *stack, int s_length, int **dst);